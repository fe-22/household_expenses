package com.fernandoalexthec.household_expenses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HouseholdExpensesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HouseholdExpensesApplication.class, args);
	}

}
