package com.fernandoalexthec.household_expenses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseholdExpensesApplicationTests {

	@Test
	void contextLoads() {
	}

}
